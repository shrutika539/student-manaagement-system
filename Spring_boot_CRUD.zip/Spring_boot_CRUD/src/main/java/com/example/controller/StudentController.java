package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.entity.Student;
import com.example.entity.Teacher;
import com.example.repository.StudentRepository;

@Controller
@RequestMapping
public class StudentController {

	@Autowired
	private StudentRepository studentRepository;

	@GetMapping("/home")
	public String viewhome(Model model) {
		model.addAttribute("students", studentRepository.findAll());
		return "index";
	}

	@GetMapping("/studenthome")
	public String studentHome(Model model) {
		model.addAttribute("students", studentRepository.findAll());
		return "studenthome";
	}

	@GetMapping("/teacherhome")
	public String teacherHome() {
		return "teacherhome";
	}

	@GetMapping("/newStudent")
	public String showStudentForm(Model model) {
		model.addAttribute("student", new Student());
		return "studentform";
	}

	@GetMapping("/newTeacher")
	public String showTeacherForm(Model model) {
		model.addAttribute("teacher", new Teacher());
		return "teacherform";
	}

	@PostMapping("/saveStudent")
	public String saveStudent(@ModelAttribute Student student) {
		studentRepository.save(student);
		return "redirect:/studenthome";
	}

	@GetMapping("/edit/{id}")
	public String editStudent(@PathVariable int id, Model model) {
		Student student = studentRepository.findById(id).orElse(new Student());
		model.addAttribute("student", student);
		return "studentform";
	}

	@PostMapping("/delete/{id}")
	public String deleteStudent(@PathVariable int id) {
		studentRepository.deleteById(id);
		return "redirect:/studenthome";
	}

}
