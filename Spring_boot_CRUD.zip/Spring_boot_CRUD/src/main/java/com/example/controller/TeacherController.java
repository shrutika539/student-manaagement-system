package com.example.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.entity.Student;
import com.example.entity.Teacher;
import com.example.repository.StudentRepository;
import com.example.repository.TeacherRepository;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

	@Autowired
	private TeacherRepository teacherRepository;
	
	private StudentRepository studentRepository;

//	@GetMapping("/home")
//	public String viewhome(Model model) {
//		model.addAttribute("teachers", teacherRepository.findAll());
//		return "index";
//	}

//	@GetMapping("/studenthome")
//	public String studentHome(Model model) {
//		model.addAttribute("students", studentRepository.findAll());
//		return "studenthome";
//	}

	@GetMapping("/teacherhome")
	public String teacherHome(Model model) {
		model.addAttribute("teachers", teacherRepository.findAll());
		return "teacherhome";
	}

//	@GetMapping("/newStudent")
//	public String showStudentForm(Model model) {
//		model.addAttribute("student", new Student());
//		return "studentform";
//	}

	@GetMapping("/newTeacher")
	public String showTeacherForm(Model model) {
		model.addAttribute("teacher", new Teacher());
		return "teacherform";
	}

	@PostMapping("/saveTeacher")
    public String saveTeacher(@ModelAttribute Teacher teacher) {
        teacherRepository.save(teacher);
        return "redirect:/teacher/teacherhome";
    }

	@GetMapping("/edit/{id}")
	public String editTeacher(@PathVariable int id, Model model) {
		Teacher teacher = teacherRepository.findById(id).orElse(new Teacher());
		model.addAttribute("teacher", teacher);
		return "teacherform";
	}

	@PostMapping("/delete/{id}")
	public String deleteTeacher(@PathVariable int id) {
		teacherRepository.deleteById(id);
		return "redirect:/teacher/teacherhome";
	}

}

