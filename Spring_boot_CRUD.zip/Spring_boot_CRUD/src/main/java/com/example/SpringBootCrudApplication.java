package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.entity.Student;
import com.example.entity.Teacher;
import com.example.repository.StudentRepository;
import com.example.services.StudentService;
import com.example.services.StudentServiceImpl;
import com.example.services.TeacherService;

@SpringBootApplication
public class SpringBootCrudApplication {

    private final StudentRepository studentRepository;

    SpringBootCrudApplication(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

	public static void main(String[] args) {
		boolean result=false;
		ApplicationContext context=SpringApplication.run(SpringBootCrudApplication.class, args);
		
		StudentService service=context.getBean(StudentService.class);
		
		//insert student
//		Student std=new Student(10, "Ajay", 60.5, 658974);
//		service.addStudent(std);
//		result=true;
//		if(result) {
//		System.out.println("data inserted");
//		}
//		else {
//			System.out.println("Try Again");
//		}
		
		// delete by id
		//service.deleteStudent(10);
		
		//update student
		//service.updateStudent(205);
		
		//System.out.println(service.readById(205)); 
		
		//System.out.println(service.stdlist().toString());
		
		TeacherService teacherservice=context.getBean(TeacherService.class);
		//insert teacher
//		Teacher teacher=new Teacher(300, "Ashish", "C");
//		teacherservice.addTeacher(teacher);
		
	//	teacherservice.deleteTeacher(300);
		
		//teacherservice.updateTeacher(201);
		
		//System.out.println(teacherservice.readByIdTeacher(201)); 
		
		//System.out.println(teacherservice.teacherlist().toString());
		
		// student services by Teacher
//		Student std=new Student(500, "Ashish", 50, 1230);
//		teacherservice.addStudent(std);
	}

}
