package com.example.services;

import java.util.List;

import com.example.entity.Student;
import com.example.entity.Teacher;

public interface TeacherService {
	public void addTeacher(Teacher teacher);
	public boolean deleteTeacher(int id);
	public boolean updateTeacher(int id);
	public Object readByIdTeacher(int id);
	public List<Teacher> teacherlist();
	
	// Student services
	public void addStudent(Student std);
	public boolean deleteStudent(int id);
	public Object readById(int id);
	public boolean updateStudent(int id);
	public List<Student>stdlist();
}
