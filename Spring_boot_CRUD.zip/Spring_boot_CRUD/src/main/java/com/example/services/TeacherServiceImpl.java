package com.example.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Student;
import com.example.entity.Teacher;
import com.example.repository.StudentRepository;
import com.example.repository.TeacherRepository;
@Service
public class TeacherServiceImpl implements TeacherService{
	@Autowired
	TeacherRepository teacherRepo;
	
	@Autowired
	StudentRepository stdRepo;
	
	@Override
	public void addTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		teacherRepo.save(teacher);
	}

	@Override
	public boolean deleteTeacher(int id) {
		// TODO Auto-generated method stub
		boolean result = false;
		teacherRepo.deleteById(id);
		result = true; 
		
		return result;
	}
	@Override
	public boolean updateTeacher(int id) {
	    Optional<Teacher> optionalTeacher = teacherRepo.findById(id);
	    
	    if (optionalTeacher.isPresent()) {
	        Teacher teacher = optionalTeacher.get();
	       teacher.setTeacher_name("Vishal");
	       teacher.setSubject("Data Science");

	        teacherRepo.save(teacher);
	        return true;
	    }
	    return false;
	}
	
	@Override
	public Optional<Teacher> readByIdTeacher(int id) {
	    return teacherRepo.findById(id);
	}

	@Override
	public List<Teacher> teacherlist() {
		// TODO Auto-generated method stub
		return teacherRepo.findAll();
	}
	
	//student services
	@Override
	public void addStudent(Student std) {
		// TODO Auto-generated method stub
		stdRepo.save(std); 
	}

	@Override
	public boolean deleteStudent(int id) {
		// TODO Auto-generated method stub
		boolean result = false;
		stdRepo.deleteById(id);
		result = true;
		
		return result;
	}

	
	@Override
	public boolean updateStudent(int id) {
	    Optional<Student> optionalStudent = stdRepo.findById(id);
	    
	    if (optionalStudent.isPresent()) {
	        Student std = optionalStudent.get();
	        std.setName("Vishal");
	        std.setMarks(80.80);
	        std.setContact(321654987L);

	        stdRepo.save(std);
	        return true;
	    }
	    return false;
	}

	@Override
	public Optional<Student> readById(int id) {
	    return stdRepo.findById(id);
	}

	@Override
	public List<Student> stdlist() {
		// TODO Auto-generated method stub
		return stdRepo.findAll();
	}

}
