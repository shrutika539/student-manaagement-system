package com.example.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Student;
import com.example.repository.StudentRepository;
@Service
public class StudentServiceImpl implements StudentService{
	@Autowired
	StudentRepository stdRepo;
	
	@Override
	public void addStudent(Student std) {
		// TODO Auto-generated method stub
		stdRepo.save(std); 
	}

	@Override
	public boolean deleteStudent(int id) {
		// TODO Auto-generated method stub
		boolean result = false;
		stdRepo.deleteById(id);
		result = true;
		
		return result;
	}

	
	@Override
	public boolean updateStudent(int id) {
	    Optional<Student> optionalStudent = stdRepo.findById(id);
	    
	    if (optionalStudent.isPresent()) {
	        Student std = optionalStudent.get();
	        std.setName("Vishal");
	        std.setMarks(80.80);
	        std.setContact(321654987L);

	        stdRepo.save(std);
	        return true;
	    }
	    return false;
	}

	@Override
	public Optional<Student> readById(int id) {
	    return stdRepo.findById(id);
	}

	@Override
	public List<Student> stdlist() {
		// TODO Auto-generated method stub
		return stdRepo.findAll();
	}


}
