package com.example.services;

import java.util.List;

import com.example.entity.Student;

public interface StudentService {
	public void addStudent(Student std);
	public boolean deleteStudent(int id);
	public Object readById(int id);
	public boolean updateStudent(int id);
	public List<Student>stdlist();
}
