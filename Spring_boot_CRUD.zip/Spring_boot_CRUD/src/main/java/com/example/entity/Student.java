package com.example.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="stdTable")
public class Student {
	@Id
	@Column
	private int id;
	@Column
	private String name;
	@Column
	private double marks;
	@Column
	private Long contact;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}

	public Long getContact() {
		return contact;
	}

	public void setContact(Long contact) {
		this.contact = contact;
	}

	public Student(int id, String name, double marks, Long contact) {
		super();
		this.id = id;
		this.name = name;
		this.marks = marks;
		this.contact = contact;
	}
	
	
	
}
